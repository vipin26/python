num = int(input("enter the number"))
'''x = 5
y = 25
print('The value of', x, 'squared is', y)
'''
print("you entered",num)

if (num%2 == 0 and num>0):
  print("num is even")
elif (num%2 != 0 and num>0):
  print("num is odd")
else:
  print("num is zero")

# print("hi") this section always print if uncommented
 

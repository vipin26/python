import time;
import calendar;
print(time.asctime(time.localtime(time.time())))  
cal= calendar.month(2019,9)
ca= calendar.prcal(2019)
print(ca)
print(cal)

i=1
n=int(input("enter a no up to which u want to print"))
for i in range (1,10,2):
   print(i)
   

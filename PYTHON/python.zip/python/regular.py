import re;

str="hii nitin how are you"
match=re.findall("how",str)

print(match)


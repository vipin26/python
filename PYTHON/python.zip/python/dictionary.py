abab={'name':'nitin','id':100}
print(abab);
print(abab.keys())
print(abab.values())

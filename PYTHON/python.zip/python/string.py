str="hello"
str1="nitin"
print(str + str1) # print hello nitin
print(str*3) # print hello 3 times
print(str[4]) # print o
print(str1[2:4]) # print ti
print('p' in str1) # print false 
print("the string str is: %s"%(str)) # print the string str is : hello

a=10
b='nitin'
c=10.6555
print(a)
print(b)
print(c)

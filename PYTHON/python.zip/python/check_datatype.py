A=10
b='hii'
c=10.5
print(type(A));
print(type(b));
print(type(c));



